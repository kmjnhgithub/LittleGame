
import UIKit

/// AppTheme：管理全局統一的顏色、字型、按鈕樣式等設計規範
struct AppTheme {

    // MARK: - 顏色設計
    struct Colors {
        /// 主要背景色
        static let background = UIColor(hex: "#F6F8FC")
        /// 主要按鈕顏色
        static let primaryButton = UIColor(hex: "#4F8EF7")
        /// 按鈕按壓時顏色
        static let buttonPressed = UIColor(hex: "#3366CC")
        /// 玩家一分數色
        static let player1 = UIColor(hex: "#FFB347")
        /// 玩家二分數色
        static let player2 = UIColor(hex: "#5BC0EB")
        /// 主要標題色
        static let title = UIColor(hex: "#212B36")
        /// 次要文字
        static let secondaryText = UIColor(hex: "#6E7782")
        /// 警示色（剩下10秒倒數時）
        static let warning = UIColor(hex: "#FF4C61")
        // 可再依需求加其他色系
    }
    
    // MARK: - 字型設計
    struct Fonts {
        static let largeTitle = UIFont.systemFont(ofSize: 36, weight: .bold)
        static let title = UIFont.systemFont(ofSize: 28, weight: .semibold)
        static let score = UIFont.systemFont(ofSize: 32, weight: .bold)
        static let body = UIFont.systemFont(ofSize: 20, weight: .regular)
        static let button = UIFont.systemFont(ofSize: 24, weight: .semibold)
    }
    
    // MARK: - 按鈕樣式
    struct Button {
        /// 統一圓角半徑
        static let cornerRadius: CGFloat = 16
        /// 陰影設定
        static let shadowOpacity: Float = 0.12
        static let shadowRadius: CGFloat = 6
        static let shadowOffset = CGSize(width: 0, height: 2)
    }
    
    // MARK: - 分數 Label 動畫
    struct Animation {
        static let scoreBounceDuration: TimeInterval = 0.15
        static let buttonPressDuration: TimeInterval = 0.09
        // 其他動畫參數可補充
    }
}

// MARK: - UIColor HEX 初始化擴充
extension UIColor {
    /// 讓UIColor支援Hex字串初始化
    convenience init(hex: String, alpha: CGFloat = 1.0) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")

        var rgb: UInt64 = 0
        Scanner(string: hexSanitized).scanHexInt64(&rgb)

        let r = CGFloat((rgb & 0xFF0000) >> 16) / 255.0
        let g = CGFloat((rgb & 0x00FF00) >> 8) / 255.0
        let b = CGFloat(rgb & 0x0000FF) / 255.0

        self.init(red: r, green: g, blue: b, alpha: alpha)
    }
}
