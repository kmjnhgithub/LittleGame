//
//  GameState.swift
//  LittleGame
//
//  Created by mike liu on 2025/5/14.
//


enum GameState {
    case playing
    case won
}
