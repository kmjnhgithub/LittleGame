
/// 遊戲邏輯控制器
/// 負責操作 Player 資料與遊戲狀態
class GameController {

}
